var html = "";
var array = [];
// 爆弾を作成する
var bom = 20;
var b_array = [];


$("img").on("click",function() {
    var index = $(".block > img").index(this);
    var id = parseInt($(this).attr("id"));
    alert("helo");

        // クリックされた場所を格納
            var x = parseInt($(this).attr("id"));
            // 中を処理
            if (x == [1-8][1-8]){
                console.log("naka:",x)                
            } else if( x == [0|9][0|9]){ 
                // 角
                console.log("kaku:",x)
            } else {
                // 辺
                console.log("hen:",x)
            }
        });


// 画面作成と爆弾作成ーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーー
$(document).ready( function(){
    for (var i = 0; i < 10 ; i++) {
        for (var j = 0; j < 10; j++) {
            html += "<div class='block'><img " + "id='" + i + j +"img'" +  "src='sprite.jpg'></div>"
            // 00~99までの配列ができる。
        }
    }
    // 1~100までの配列に数字を入れる
     $("#main").html(html);

    // 爆弾を作成する
    while (b_array.length < bom) {
        let num = Math.floor(Math.random() * 99) + 1;        
        if (b_array.indexOf(num) === -1) {
            b_array.push(num);
            $(".block > img").eq(num).css("margin-left",-300);
        }
    }
    console.log(b_array);
});


            // 辺を処理



            // 見つかった爆弾の数に合わせてクリック箇所の変更
//             $(this).css('margin-left', -30);

// });
